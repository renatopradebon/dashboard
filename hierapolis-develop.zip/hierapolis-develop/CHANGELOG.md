
#### [Current]
 * [1a07395](../../commit/1a07395) - __(Tayfun Ozis ERIKAN)__ Bump version 0.5.2
 * [ee11dcc](../../commit/ee11dcc) - __(Tayfun Ozis ERIKAN)__ Directory indexes was disabled

#### 0.5.0
 * [e8c7f44](../../commit/e8c7f44) - __(Tayfun Ozis ERIKAN)__ Bump version 0.5.0
 * [03ca365](../../commit/03ca365) - __(Tayfun Ozis ERIKAN)__ #TB-40 Middleman updates and improvements - Middleman gems were updated - HAML layout structures were updated - Bootstrap-sass was updated - Middleman-deploy plugin was enabled and rakefile was removed - .gitignore file was updated
 * [066dc2e](../../commit/066dc2e) - __(Muhammet Dilek)__ Merge pull request [#48](../../issues/48) from ds82/fix/middleman-sprockets

lock version of middleman-sprockets to 3.3.2 due to a bug
 * [62e8249](../../commit/62e8249) - __(Dennis Saenger)__ lock version of middleman-sprockets to 3.3.2 due to a bug

see: https://github.com/middleman/middleman/issues/1265

 * [7746060](../../commit/7746060) - __(Onur zgr ZKAN)__ Give more information about run and build middleman
 * [d23d1f3](../../commit/d23d1f3) - __(Ahmet Sezgin Duran)__ LAB-31 #time 1m Add named logo
 * [fabb176](../../commit/fabb176) - __(Ahmet Sezgin Duran)__ LAB-31 #time 2m Update README.md and license
 * [5ba05d3](../../commit/5ba05d3) - __(Onur zgr ZKAN)__ Add rails hierapolis gem.
 * [4a80ca9](../../commit/4a80ca9) - __(Muhammet DILEK)__ github pages settings
 * [bb47ca7](../../commit/bb47ca7) - __(Tayfun zi ERKAN)__ [#45](../../issues/45) was done
 * [a2ae457](../../commit/a2ae457) - __(Tayfun Ozis ERIKAN)__ [#42](../../issues/42) Bootstrap was updated.
 * [a61f895](../../commit/a61f895) - __(Tayfun Ozis ERIKAN)__ [#41](../../issues/41) Middleman, bootstrap-sass were updated.
 * [5fef629](../../commit/5fef629) - __(Tayfun Ozis ERIKAN)__ [#41](../../issues/41) Screenshots was added.

#### 0.4.0
 * [1791946](../../commit/1791946) - __(Tayfun Ozis ERIKAN)__ bump version 0.4.0
 * [ae6428e](../../commit/ae6428e) - __(Tayfun Ozis ERIKAN)__ 31 Add more content view helpers - Navbar variables were fixed - Panel tools was fixed - Dropdown launcher menu position was fixed
 * [371d9d1](../../commit/371d9d1) - __(Tayfun Ozis ERIKAN)__ 31 Add more content view helpers - Panel dimensions and colors was fixed - Font files was removed
 * [b6f0f0f](../../commit/b6f0f0f) - __(Tayfun Ozis ERIKAN)__ 31 Add more content view helpers - Toolbar yield content was added - Font-family was added to global variables
 * [4fc953c](../../commit/4fc953c) - __(Tayfun Ozis ERIKAN)__ 31 Add more content view helpers - Breadcrumb yield content was added
 * [840b303](../../commit/840b303) - __(Tayfun Ozis ERIKAN)__ [#28](../../issues/28) Form headings was changed with fieldset and legend tags.
 * [29bfd35](../../commit/29bfd35) - __(Tayfun Ozis ERIKAN)__ [#2](../../issues/2) Configure Middleman i18n  - i18n was enabled  - Sign in and forgot password page's translations was added
 * [da668bd](../../commit/da668bd) - __(Tayfun Ozis ERIKAN)__ [#22](../../issues/22) Design login layout - Login layout was created - Sign in page was created - Forgot password page was created
 * [ebf27f1](../../commit/ebf27f1) - __(Tayfun Ozis ERIKAN)__ [#30](../../issues/30) Create tables page - Pagination controls was added - Row actions was added - Row states was added
 * [5a42f4b](../../commit/5a42f4b) - __(Tayfun Ozis ERIKAN)__ [#30](../../issues/30) Create tables page - Table th and td padding values was fixed - Table header and table footer was added - 'tables' css class was added to panels
 * [7a444bb](../../commit/7a444bb) - __(Tayfun Ozis ERIKAN)__ [#30](../../issues/30) Create tables page - Table variations was added
 * [cc04127](../../commit/cc04127) - __(Tayfun Ozis ERIKAN)__ [#30](../../issues/30) Create tables page - Quick search and filters was added
 * [4cc2d8b](../../commit/4cc2d8b) - __(Tayfun Ozis ERIKAN)__ [#30](../../issues/30) Create tables page - Table variations was adde - No-padding panel was fixed for table usage
 * [fa4375b](../../commit/fa4375b) - __(Tayfun Ozis ERIKAN)__ Dashboard improvements
 * [74a5849](../../commit/74a5849) - __(Tayfun Ozis ERIKAN)__ [#28](../../issues/28) Create forms page - Jquery knob plugin was added
 * [13f8847](../../commit/13f8847) - __(Tayfun Ozis ERIKAN)__ [#28](../../issues/28) Create forms page - Many form variations were added.
 * [7173671](../../commit/7173671) - __(Tayfun Ozis ERIKAN)__ [#29](../../issues/29) Layout overflow problems was fixed.
 * [4edfef7](../../commit/4edfef7) - __(Tayfun Ozis ERIKAN)__ [#28](../../issues/28) Create forms page - Default and horizontal forms were added - Bootstrap overrides sass file was added
 * [c84da35](../../commit/c84da35) - __(Tayfun Ozis ERIKAN)__ [#27](../../issues/27) Custom view helpers was created
 * [b7949e1](../../commit/b7949e1) - __(Tayfun Ozis ERIKAN)__ [#26](../../issues/26) Panel icon, title and toolbar was added
 * [a54209d](../../commit/a54209d) - __(Tayfun Ozis ERIKAN)__ [#21](../../issues/21) Continues - Primary toolbar was created - Some bootstrap overrides was done - Navbar icons was added - Navbar badges was added - User profile image was added - Dock text toggle was added
 * [75bce46](../../commit/75bce46) - __(Tayfun Ozis ERIKAN)__ [#21](../../issues/21) Continues - Beaker added to the bottom of the dock. - Breadcrumb position was fixed
 * [9802e61](../../commit/9802e61) - __(Tayfun Ozis ERIKAN)__ [#21](../../issues/21) Continues - Dropdown menu styles were done - Dock dropdown menus were created - Dropdown menu hover effect was added
 * [0806b7c](../../commit/0806b7c) - __(Tayfun Ozis ERIKAN)__ [#21](../../issues/21) Continues - Active item's highlight was added to the dock.
 * [d029c03](../../commit/d029c03) - __(Tayfun Ozis ERIKAN)__ [#21](../../issues/21) Continues - Dock position was done - Navbar position was done - Content position was done
 * [fe87883](../../commit/fe87883) - __(Tayfun Ozis ERIKAN)__ [#21](../../issues/21) Continues - Prepare layout - Prepare color swatches - Prepare variables

#### 0.3.0
 * [acb8dce](../../commit/acb8dce) - __(Tayfun Ozis ERIKAN)__ 0.3.0
 * [78661d9](../../commit/78661d9) - __(Tayfun Ozis ERIKAN)__ [#20](../../issues/20) Twitter Bootstrap 3  integration - Flat UI was removed - Bootstrap-sass (branch name: 3) gem was installed - Twitter Bootstrap 3 RC1 was integrated - Removed all unused files
 * [96b9a9e](../../commit/96b9a9e) - __(Tayfun zi ERKAN)__ Update README.md
 * [b59ecc8](../../commit/b59ecc8) - __(Tayfun zi ERKAN)__ Update README.md
 * [5a2349c](../../commit/5a2349c) - __(Tayfun zi ERKAN)__ Update README.md
 * [3cba739](../../commit/3cba739) - __(Tayfun Ozis ERIKAN)__ MIT license was added.
 * [6c19329](../../commit/6c19329) - __(Tayfun zi ERKAN)__ Version was updated.

#### 0.2.0
 * [1d76b56](../../commit/1d76b56) - __(coskuntekin)__ [#9](../../issues/9) Added Flat UI
 * [366ec3d](../../commit/366ec3d) - __(coskuntekin)__ gitignore was updated.

#### 0.1.0
 * [de1e5a9](../../commit/de1e5a9) - __(Tayfun Ozis ERIKAN)__ Bump version 0.1.0
 * [ceae0f2](../../commit/ceae0f2) - __(coskuntekin)__ [#8](../../issues/8) Font 'open sans' was integrated.
 * [a221df3](../../commit/a221df3) - __(coskuntekin)__ [#3](../../issues/3) Font awesome was integrated.
 * [4b1b2f1](../../commit/4b1b2f1) - __(Tayfun Ozis ERIKAN)__ [#1](../../issues/1) Rubygems source switched to https
 * [57f5f93](../../commit/57f5f93) - __(coskuntekin)__ fixed index.html.haml
 * [1c220c1](../../commit/1c220c1) - __(coskuntekin)__ [#1](../../issues/1) install middleman
